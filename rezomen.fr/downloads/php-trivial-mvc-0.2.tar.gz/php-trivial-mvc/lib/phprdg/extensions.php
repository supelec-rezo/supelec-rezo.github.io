<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**
	Effectue une sauvegarde d'une base de données dans un fichier.
		@param	string	$connection_key	Clé de la base de données (telle que défini
			dans config.php)
		@param	string	$output_file	Chemin absolu du fichier de sortie
		@param	boolean	$options
			structure (défaut : false)	Sauvegarde la structure des tables
			data (défaut : true)	Sauvegarde les données des tables
			drop_table (défaut : true)	Ajoute la mention "DROP TABLE IF EXISTS" (appliqué uniquement si sauvegarde de la structure)
			truncate (défaut : true)	Ajoute la mention "TRUNCATE TABLE" (appliqué uniquement si sauvegarde des données)
		@return	boolean	Succès ou échec
*/

function rdg_backup_database($connection_key, $output_file, $options = array())
{
	global $RDG_CONNECTIONS;

	// Récupération des options
	if (! array_key_exists('structure', $options)) $options['structure'] = false;
	if (! array_key_exists('data', $options)) $options['data'] = true;
	if (! array_key_exists('drop_table', $options)) $options['drop_table'] = true;
	if (! array_key_exists('truncate', $options)) $options['truncate'] = true;

	// Connexion à la B.D.
	if (! array_key_exists($connection_key, $RDG_CONNECTIONS))
		return false;
	$link = rdg_connect($RDG_CONNECTIONS[$connection_key]['host'],
		$RDG_CONNECTIONS[$connection_key]['user'],
		$RDG_CONNECTIONS[$connection_key]['pass'],
		$RDG_CONNECTIONS[$connection_key]['base']);
	if (! $link)
		return false;

	// Récupération de la liste des tables
	$query = "SHOW TABLES FROM ".rdg_p2($RDG_CONNECTIONS[$connection_key]['base']);
	if (! $r = mysql_query($query, $link))
		throw new RDGExceptionMySQL(mysql_error($link), $query);
	$tables = array();
	while ($l = mysql_fetch_row($r))
		$tables[] = $l[0];

	// Ouverture du fichier de sortie en écriture
	$f = @fopen($output_file, "w");
	if (! $f)
		throw new Exception("Impossible de créer le fichier '$output_file'. Vérifiez les permissions sur le serveur.");

	// En-tête
	$head = "--\n";
	$head .= "-- Serveur: ".$RDG_CONNECTIONS[$connection_key]['host']."\n";
	$head .= "-- Généré le : ".date("Y-m-d, H:i:s")."\n";
	$head .= "-- Base de données: ".rdg_p2($RDG_CONNECTIONS[$connection_key]['base'])."\n";
	$head .= "--\n";
	$head .= "-- --------------------------------------------------------\n\n";
	fwrite($f, $head);


	foreach ($tables as $table)
	{
		if ($options['structure'])
		{
			$head = "--\n";
			$head .= "-- Structure de la table ".rdg_p2($table)."\n";
			$head .= "--\n\n";
			fwrite($f, $head);

			if ($options['drop_table'])
				fwrite($f, "DROP TABLE IF EXISTS ".rdg_p2($table).";\n");

			$query = "SHOW CREATE TABLE ".rdg_p2($table);
			if (! $r2 = mysql_query($query, $link))
				throw new RDGExceptionMySQL(mysql_error($link), $query);

			$l = mysql_fetch_array($r2);
			fwrite($f, $l[1].";\n\n");
		}

		if ($options['data'])
		{
			$head = "--\n";
			$head .= "-- Contenu de la table ".rdg_p2($table)."\n";
			$head .= "--\n\n";
			fwrite($f, $head);

			fwrite($f, "TRUNCATE TABLE ".rdg_p2($table).";\n");

			$query = "SELECT * FROM ".rdg_p2($table);
			if (! $r2 = mysql_query($query, $link))
				throw new RDGExceptionMySQL(mysql_error($link), $query);

			$nb_results = mysql_num_rows($r2);
			if ($nb_results > 0)
			{
				$fields = "";
				$nb_fields = mysql_num_fields($r2);
				for ($i = 0; $i < $nb_fields; $i++)
				{
					if ($i > 0)
						$fields .= ", ";
					$fields .= rdg_p2(mysql_field_name($r2, $i));
				}

				$data = "INSERT INTO ".rdg_p2($table)." ($fields) VALUES \n";

				for ($k = 0; $k < $nb_results; $k++)
				{
					$l = mysql_fetch_row($r2);
					$data .= "(";
					for($i = 0; $i < $nb_fields; $i++)
					{
						if ($i > 0)
							$data .= ", ";
						$data .= rdg_p($l[$i]);
					}
					$data .= ")";
					if ($k < $nb_results - 1)
						$data .= ",\n";
				}

				fwrite($f, $data.";\n\n");
			}
		}
	}

	/* Astuce qui permettra de savoir si la sauvegarde a bien été restaurée
	complètement le cas échéant. */
	fwrite($f, "SELECT \"Terminé\";\n");

	fclose($f);

	return true;
}


/**
	Restauration d'une sauvegarde.
	(utilisation de l'extension Mysqli [http://www.php.net/mysqli])
		@param	string	$connection_key	Clé de la base de données (telle que défini
			dans config.php) dans laquelle la sauvegarde sera restaurée
		@param	string	$file	Chemin du fichier de sauvegarde
		@return boolean
*/
function rdg_restore_database($connection_key, $file)
{
	global $RDG_CONNECTIONS;

	/* Récupération du fichier */
	if (! file_exists($file))
		return false;
	$query = file_get_contents($file);

	/* Connexion à la B.D. */
	if (! array_key_exists($connection_key, $RDG_CONNECTIONS))
		return false;
	$mysqli = new Mysqli($RDG_CONNECTIONS[$connection_key]['host'], $RDG_CONNECTIONS[$connection_key]['user'], $RDG_CONNECTIONS[$connection_key]['pass'], $RDG_CONNECTIONS[$connection_key]['base']);
	if (mysqli_connect_errno())
		return false;

	/* Execution de la requête et analyse des résultat (on se base sur le fait que
	la dernière requête doit être SELECT "Terminé", et qu'elle est exécutée
	uniquement s'il n'y a pas eu de problèmes avant). */
	$mysqli->query("SET NAMES 'utf8'");
	if ($mysqli->multi_query($query))
	{
		$last_result = null;
		do
		{
			if ($result = $mysqli->use_result())
			{
				while ($row = $result->fetch_row())
				{
					$last_result = $row[0];
				}
				mysqli_free_result($result);
			}

		} while ($mysqli->next_result());
		if ($last_result == "Terminé")
			$return = true;
		else
			$return = false;
	}
	else
		$return = false;

	$mysqli->close();

	return $return;
}
?>