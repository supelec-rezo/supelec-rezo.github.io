<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et conditions.

*/

/**
	Classe de base de PHP View. Elle permet de récupérer toutes les infos
	sur les vues, de les compiler, et de les afficher.
*/
class View
{
	// Template (vue) et layout
	private $template = null;
	private $layout = null;

	// On peut spécifier un layout pour le rendu des exceptions
	private $exception_layout = null;

	// Inclusion de fichiers CSS ou JS dans la vue
	private $js_files = array();
	private $css_files = array();

	// Assignation des variables passées à la vues
	private $assigns = array();

	// Permet de se souvenir si on a ouvert le cache de rendu (utile en cas de
	// levée d'une exception, cf. methodes render et render_exception).
	private $ob_started = false;

	/**
		Redirection (on peut choisir cela, dans une action d'un contrôleur, plutôt
		que de rendre une vue).
			@param	string	$url
			@param	boolean	$permanent
	*/
	public static function redirect($url, $permanent = false)
	{
		if ($permanent)
			header("Status: 301 Moved Permanently");
		else
			header("Status: 302 Found");
		header("location: $url");
	}

	/**
		Spécifie le template à utiliser, si ce n'est pas celui par défaut
		([controller]/[action]).
		@param  string  Chemin du template sans le ".php" final, à partir de
			"views/" s'il contient un slash ou à partir de "views/[controleur]" s'il
			ne contient pas de slash. Exemples : set_template("livre/list");
			set_template("index");
	*/
	public function set_template($template)
	{
		if (strpos($template, '/') === false)
			$this->template = 'views/' . CONTROLLER . '/' . $template . '.php';
		else
			$this->template = 'views/' . $template . '.php';
	}

	/**
		Spécifie le layout à appliquer, si ce n'est pas celui par défaut
		("application"). Pour ne pas appliquer de layout, entrer FALSE.
		@param  string  Chemin du layout à partir de "layouts/" et sans l'extension
			".layout.php". Exemple : set_layout("mon_layout");
	*/
	public function set_layout($layout)
	{
		if ($layout)
			$this->layout = 'layouts/'.$layout.'.layout.php';
		else
			$this->layout = false;
	}

	/**
		Spécifie le layout à appliquer dans le cas où une exception est levée, si ce
		n'est pas celui par défaut ("application"). Pour ne pas appliquer de layout,
		entrer FALSE.
		@param  string  Chemin du layout à partir de "layouts/" et sans l'extension
			".layout.php". Exemple : set_exception_layout("mon_layout");
	*/
	public function set_exception_layout($layout)
	{
		if ($layout)
			$this->exception_layout = 'layouts/'.$layout.'.layout.php';
		else
			$this->exception_layout = false;
	}

	/**
		Ajoute une variable dans l'espace de nom de la vue.
			@param  string  $name   Nom de la variable (la variable dont le nom est
				"toto" sera accessible dans la vue par l'intermédiaire de $_toto : un
				tirêt bas est rajouté).
			@param  string  $value  Valeur de la variable.

		N.B. Les variables commençant par '_' sont automatiquement ajoutées, il
		n'y a pas besoin d'utiliser cette méthode. En outre, en cas de
		chevauchement, les valeurs passées par l'intermédiaire de add_var sont
		prioritaires par rapport aux variables automatiquement ajoutées.
	*/
	public function add_var($name, $value)
	{
		$this->assigns[$name] = $value;
	}

	/**
		Ajoute une feuille de style.
	*/
	public function add_css_file($filename)
	{
		$this->css_files[] = $filename;
	}

	/**
		Ajoute un fichier de scripts.
	*/
	public function add_js_file($filename)
	{
		$this->js_files[] = $filename;
	}

	/**
		Compile la vue. Cette fonction est destinée à être appelée à la fin d'une
		action d'un contrôleur. Les variables dont le nom commence par un tirêt-bas
		(_) ainsi que les variables explicitement spécifiées par l'intermédiaire
		de la méthode add_var sont passées à la vue (cf. documentation de la méthode
		add_var).
	*/
	public function render()
	{
		header('Content-Type: text/html; charset=UTF-8');

		/* Recherche du template */
		if (! $this->template)
			$this->template = 'views/' . CONTROLLER . '/' . ACTION . '.php';

		if (! file_exists($this->template))
			throw new Exception("Template '$this->template' not found.");

		/* Recherche du layout (qui peut volontairement être à FALSE). La valeur
		NULL signifie qu'il n'a pas encore été défini. */
		if ($this->layout === null)
			$this->layout = 'layouts/application.layout.php';

		if ($this->layout && ! file_exists($this->layout))
			throw new Exception("Layout '$this->layout' not found.");

		/* Assignation des variables passées à la vues */
		// Automatique : variables commençant par "_"
		$assigns = array();
		foreach ($GLOBALS as $key => $value)
		{
			if (strlen($key) >= 2 && $key[0] == '_' && !in_array($key, array("_ENV", "_POST", "_GET", "_COOKIE", "_SERVER", "_FILES", "_REQUEST", "_SESSION")))
				$assigns[$key] = $value;
		}

		// Manuel : variables ajoutées via add_var();
		foreach ($this->assigns as $k => $v)
			$assigns['_'.$k] = $v;
		extract($assigns);

		/* Rendu */
		ob_start(); // A partir de ce moment, les "echo" ne s'afficheront plus mais seront mis en cache.
		$this->ob_started = true;
		if ($this->layout)
		{
			require($this->template);

			// 3 variables supplémentaires passées au layout
			$_content = ob_get_contents(); // Récupération du contenu mis en cache.
			$_js_files = $this->js_files;
			$_css_files = $this->css_files;

			ob_end_clean(); // Nettoyage du cache
			ob_start(); // Ouverture d'un nouveau cache (utile au cas où une exception se produit dans le layout)
			require($this->layout);
			$result = ob_get_contents(); // Récupération du contenu mis en cache.
		}
		else
		{
			require($this->template);
			$result = ob_get_contents(); // Récupération du contenu mis en cache.
		}
		ob_end_clean(); // Nettoyage du cache
		echo $result;	// Affichage de la vue.
		exit;
	}

	/**
		Compile la vue dans le cas où une exception a été levée.
			@param	Exception	$exception	L'exception fautive.
	*/
	public function render_exception(Exception $exception)
	{
		header('Content-Type: text/html; charset=UTF-8');

		/* Choix du template */
		$classname = get_class($exception);
		$exception_template = 'views/exception/' . self::basename_of_classname($classname) . '.php';
		if (! file_exists($exception_template))
			$exception_template = 'views/exception/exception.php';

		/* Recherche du template */
		if (! file_exists($exception_template))
			die("An exception occured. Besides, this exception's template can't be found.");


		/* Recherche du layout (qui peut volontairement être à FALSE). La valeur
		NULL signifie qu'il n'a pas encore été défini. */
		if ($this->exception_layout === null)
			$this->exception_layout = 'layouts/application.layout.php';

		if ($this->exception_layout && ! file_exists($this->exception_layout))
			die("An exception occured. Besides, the layout can't be found.");

		/* Si un rendu avait déjà été commencé, on le supprime */
		if ($this->ob_started)
			ob_end_clean(); // Nettoyage du cache

		// 1 variable passée à la vue, qu'on affiche un layout ou pas.
		$_exception = $exception;
		if ($this->exception_layout)
		{
			ob_start(); // A partir de ce moment, les "echo" ne s'afficheront plus mais seront mis en cache.
			$this->ob_started = true;
			require($exception_template);

			// 3 variables supplementaires passées au layout
			$_content = ob_get_contents(); // Récupération du contenu mis en cache.
			$_js_files = $this->js_files;
			$_css_files = $this->css_files;

			ob_end_clean(); // Nettoyage du cache
			require($this->exception_layout);	// L'affichage réel se fait là
		}
		else
			require($exception_template);
		exit;
	}

	/*****************************************************************************
		Utilitaires embarqués.
	*****************************************************************************/
	/**
		Rend le nom conventionnel du fichier définissant une classe (utilisé pour
		choisir la vue qui doit afficher une exception).
			@param   string  Nom de la classe (exemple : MaClasse).
			@return  string  Nom du fichier (exemple : ma_classe).
	*/
	private static function basename_of_classname($classname)
	{
		$r = "";
		for ($i = 0; $i < strlen($classname); $i ++)
		{
			$chr = $classname[$i];
			$ord = ord($chr);
			if ($ord >= 65 && $ord <= 90)
			{
				$ord += 32;
				if ($i > 0)
					$r .= '_';
				$r .= chr($ord);
			}
			else
				$r .= $chr;
		}
		return $r;
	}
}
?>
