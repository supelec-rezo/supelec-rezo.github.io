<?php
if (! defined('CONTROLLER')) exit;

/**
	Exemple de template.
*/
?>

<h2>Exemple CRUD</h2>

<p>Nous allons voir comment PHP Trivial MVC vous permet de construire une
structure de base pour votre application en quelques secondes.</p>

<p style="font-style:italic;">Dernière mise à jour pour la version 0.2.</p>


<hr />
<h3>Etape 1 : créer la base de données</h3>

<p>Créez les tables suivantes :</p>

<p><pre>
CREATE TABLE `authors`(
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 `name` VARCHAR(50),
 `country` VARCHAR(50),
 `born` DATE
);

CREATE TABLE `books`(
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 `title` VARCHAR(50),
 `published` DATE,
 `author_id` INT
);
</pre></p>

<p>Ajustez ensuite le fichier <code>include/config.php</code> pour permettre à
l'application de se connecter à la base de données.</p>


<hr />
<h3>Etape 2 : générer un échaffaudage pour la table "authors"</h3>

<p>Exécutez la ligne de commande suivante, qui permet de générer un modèle,
un contrôleur, et des vues par défaut pour une table (assurez vous que php en ligne
de commande est installé : paquet <i>php5-cli</i> pour Debian Etch) :</p>

<p><pre>php5 script/scaffold.php</pre><p>

<p>A la demande
"Class name:", répondez "Author" (avec la majuscule initiale, et sans <i>"s"</i>) puis <i>Entrée</i>. Le script
demande encore trois paramètres. Les valeurs par défaut (entre parenthèses)
conviennent, il suffit donc de taper sur <i>Entrée</i>.</p>

<p>Pour voir le résultat, rendez vous, avec votre navigateur, sur le
contrôleur : <a href="authors.php" target="_blank">authors.php</a>. Vous
pouver commencer à entrer des données.</p>


<hr />
<h3>Etape 3 : générer un échaffaudage pour la table "books"</h3>

<p>Exécutez à nouveau :</p>

<p><pre>php5 script/scaffold.php</pre><p>

<p>A la demande "Class name:", répondez "Book". Appuyez encore
trois fois sur <i>Entrée</i>.</p>

<p>Cette fois, le script détecte la présence d'un
champ se terminant par "_id" dans la table de la base de données. Il devine
qu'il s'agit d'une association. A la question : <i>"Is 'author_id' a foreign key of a belongs to association ?"</i>,
répondez <i>"y"</i> (ou tapez simplement <i>Entrée</i>). Le script vous propose
ensuite trois paramètres pour configurer l'association; les valeurs
par défaut devraient convenir.</p>

<p>Pour voir le résultat, rendez vous, avec votre navigateur, sur le
contrôleur : <a href="books.php" target="_blank">books.php</a>.</p>


<hr />
<h3>Etape 4 : améliorations possibles</h3>

<p>Libre à vous d'améliorer le code source généré ou celui de PHP Trivial MVC ! Voici quelques pistes :</p>

<h4>Modifier les vues</h4>

<p>Dans les fichiers <code>views/authors/_form.php</code> et <code>views/books/_form.php</code>,
remplacez <code>text_field</code> par <code>date_field</code> pour les champs <i>born</i>
et <i>published</i>.</p>


<h4>Ajouter des conditions pour valider un enregistrement</h4>

<p>Voir les exemples inclus dans la méthode <code>validation()</code> des
modèles <code>models/author.class.php</code> et <code>models/book.class.php</code>.</p>


<h4>Ajouter une association "has many"</h4>

<p>C'est l'association opposée à l'association "belongs to". Exécutez :</p>

<pre>php5 script/associations.php</pre>

<p>et entrez les paramètres suivants :</p>

<pre>Association type : has many
Class name : Author
Model file name : author.class.php
Towards class : Book
Association name : books
Foreign key : book_id</pre>

<p>Cela a pour effet d'ajouter une méthode <code>books()</code> à la classe
<code>Author</code>.</p>

<h4>Ajouter des callbacks</h4>

<p>Vous pouvez par exemple (ré)écrire la méthode <code>after_destroy</code> héritée
de la classe <code>RDG</code> dans le modèle <code>Author</code>
(fichier <code>author.class.php</code>) pour faire en sorte que lorsqu'on supprime
un auteur, les livres éventuellement associés soient également supprimés.
Lire la documentation et le code de la librairie PhpRDG (répertoire <code>lib/phprdg/</code>)
pour plus d'informations.</p>

<p>Exemple :</p>

<pre>protected function after_destroy()
{
  Book::meta()->destroy_all("author_id = ".$this->id);
}</pre>

<p></p>

