<?php
if (! defined('CONTROLLER')) exit;

/**
	Exemple de template.
*/
?>

<p>Hi <b><?php echo $_name; ?></b> !</p>

<p><a href="index.php">Accueil</a></p>