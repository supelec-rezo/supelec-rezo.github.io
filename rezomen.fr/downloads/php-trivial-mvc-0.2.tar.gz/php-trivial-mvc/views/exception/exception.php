<?php
if (! defined('CONTROLLER')) exit;

/**
	Exemple de template pour le traitement des exceptions.
*/
?>

<div class="error">
<?php
echo "<p>An exception occured".($exception->getMessage() ? " :" : ".")."</p>";
if ($exception->getMessage())
	echo "<p class='emphasize'>".$exception->getMessage()."</p>";

if (EXCEPTION_DETAILS)
{
	echo "<p>Trace :</p>";

	echo "<p class='error_detail'>File : ".$exception->getFile()."<br />
	Line : ".$exception->getLine()."<br />
	".implode("<br />#", explode("#", $exception->getTraceAsString()))."</p>";
}
?>
</div>
