<?php
/**
	Exemple de contrôleur.

	Les deux premieres lignes permettent de découvrir le nom du contrôleur et de
	l'action demandée. Ensuite, après avoir inclus les dépendances de
	l'application, les actions sont écrites (une action par "case"). Le tout est
	enveloppé par un bloc try / catch afin de traiter proprement les exceptions.
*/

define('CONTROLLER', substr(basename(__FILE__), 0, strlen(basename(__FILE__)) - 4));
define('ACTION', isset($_GET['a']) ? $_GET['a'] : 'index');

try
{
	require 'include/include.php';

	switch (ACTION)
	{
		/*************************************************************************/
		case 'index':
			$view->render(); // Rendu de la vue (par défaut : views/index.php)
		break;

		/*************************************************************************/
		case 'example':
			$view->render(); // Rendu de la vue (par défaut : views/index.php)
		break;

		/*************************************************************************/
		case 'example2':
			$_name = param('name');
			// Les variables commençant par un tiret bas ("_") sont accessibles dans la vue.
			$view->render(); // Rendu de la vue (par défaut : views/example.php)
		break;

		/*************************************************************************/
		case 'example_crud':
			$view->render(); // Rendu de la vue (par défaut : views/index.php)
		break;

		/*************************************************************************/
		default :
			throw new Exception("Action '".ACTION."' unknown.");
		break;
	}
}
catch (Exception $e)
{
	$view->render_exception($e);
}
?>
