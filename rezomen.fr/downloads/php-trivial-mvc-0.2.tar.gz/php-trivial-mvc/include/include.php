<?php
if (! defined('CONTROLLER')) exit; // On empêche l'exécution de ce fichier hors des contrôleurs.

/**
	Inclusion des dépendances de l'application.

	Ce fichier est à appeler depuis les contrôleurs, qui sont placés à la racine
	de l'application. Les chemins relatifs sont donc à exprimer depuis la racine
	de l'application.
*/

// Projets PHP View (gestion des templates) et PHP RDG (gestion des modèles)
require 'lib/phpview/include.php';
require 'lib/phprdg/include.php';

// Configuration de l'application
require 'include/config.php';

// Fonctions pratiques
require 'include/helpers.php';
require 'include/helpers_form.php';
require 'include/flash.php';

// Modèles
$hdir = opendir("models/");
while (($file = readdir($hdir)) !== false)
{
	if (! is_dir($file) && ereg("\.php$", $file))
		require "models/".$file;
}
closedir($hdir);

// Instanciation de la vue (les contrôleurs agissent sur cet objet).
$view = new View;
?>
