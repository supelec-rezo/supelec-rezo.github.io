<?php
session_start();

/**
	Enregistrement d'un flash.
		@param	string	$name	Nom sous lequel est enregistrée la valeur (exemples :
			"notice", "warning", ...).
		@param	string	$content	Valeur à enregistrer.
*/
function flash($name, $content)
{
	$_SESSION['flash'][$name] = $content;
}


/**
	Efface l'ensemble des flashs.
*/
function flash_flush()
{
	unset($_SESSION['flash']);
}


/**
	Affichage du contenu de tous les flashs.
*/
function flash_display()
{
	if(isset($_SESSION['flash']))
	{
		foreach($_SESSION['flash'] as $name => $content)
		{
			if ($name == 'notice')
				echo "<p class='flash_notice'>".$content."</p>";
			else if ($name == 'warning')
				echo "<p class='flash_warning'>".$content."</p>";
			else
				echo "<p>".$content."</p>";
		}
		flash_flush();
	}
}
?>