<?php
if (! defined('CONTROLLER')) exit; // On empêche l'exécution de ce fichier hors des contrôleurs.

/**
	Configuration de l'application.

	Ce fichier est appelé dans "include.php".
*/

/*
	Affichage ou non d'un maximum de détails lors des erreurs. Utile pendant la
	phase de développement, mais pas super sécu en production.
*/
error_reporting(E_ALL); // Erreur PHP
define('EXCEPTION_DETAILS', true); // Lors de l'affichage d'une exception,
		// doit-on montrer la trace ? (nom des fonctions, noms des fichiers, numéros
		// de lignes, ...).

/*
	Configuration de PHPRDG (accès à la base de données).
	(cf. fichier lib/phprdg/config.php)
*/
$RDG_CONNECTIONS = array(
	'default' => array(
								"host" => "localhost",
								"user" => "root",
								"pass" => "",
								"base" => "test",
							)
);
?>
