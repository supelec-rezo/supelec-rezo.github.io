<?php
	// has_many : {{ASSOCIATION_NAME}}
	private $_{{ASSOCIATION_NAME}} = false;
	public function {{ASSOCIATION_NAME}}($force_reload = false)
	{
		if ($force_reload || $this->_{{ASSOCIATION_NAME}} === false)
			$this->_{{ASSOCIATION_NAME}} = {{FOREIGN_CLASS_NAME}}::meta()->find_all("{{FOREIGN_KEY}} = ".rdg_p($this->id));
		return $this->_{{ASSOCIATION_NAME}};
	}
?>
