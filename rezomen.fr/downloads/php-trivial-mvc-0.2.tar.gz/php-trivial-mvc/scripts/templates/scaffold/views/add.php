<h1>New {{VAR_SING}}</h1>

<form method="post" action="{{VAR_PLUR}}.php?a=create">
	<?php require "_form.php"; ?>
	<p>
		<input type="submit" name="submit" id="submit" value="OK" />
		<input type="button" name="cancel" id="cancel" value="Cancel" onclick="javascript:location.href='{{VAR_PLUR}}.php';" />
	</p>
</form>
