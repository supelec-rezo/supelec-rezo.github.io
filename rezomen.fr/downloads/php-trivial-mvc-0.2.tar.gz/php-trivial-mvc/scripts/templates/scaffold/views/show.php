<h1>{{TEXT_SING_UCFIRST}}</h1>

<table>
{{ATTRIBUTES_SHOW}}
</table>

<p>
	<a href="{{VAR_PLUR}}.php?a=edit&amp;id=<?php echo $_{{VAR_SING}}->id; ?>&amp;r=show">Edit</a>
|	<a href="{{VAR_PLUR}}.php?a=destroy&amp;id=<?php echo $_{{VAR_SING}}->id; ?>" onclick="<?php echo confirm_onclick(); ?>">Delete</a>
|	<a href="{{VAR_PLUR}}.php">Index</a>
</p>