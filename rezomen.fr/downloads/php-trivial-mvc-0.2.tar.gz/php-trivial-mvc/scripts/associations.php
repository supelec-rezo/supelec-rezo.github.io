<?php
/**

	Ce fichier permet d'ajouter des associations de type "belongs to" ou
	"has many" a des modèles existants.
	
	Il s'exécute en mode console (commande "php" ou "php5"). Pour des raisons
	de sécurité, vous devriez supprimer le dossier "scripts" une fois la phase de
	développement terminée.

*/
if (php_sapi_name() != "cli")
	die("Ce script ne peut être utilisé qu'en ligne de commande.");

define("CONTROLLER", "SCAFFOLD"); // Pour pouvoir utiliser le fichier config.php

define("SCRIPTS_DIR", dirname(__FILE__)."/");
define("TEMPLATES_DIR", SCRIPTS_DIR."templates/associations/");
require SCRIPTS_DIR."../include/config.php";
require SCRIPTS_DIR."../lib/phprdg/include.php";

function read($length='255')
{
	if (! isset ($GLOBALS['STDIN']))
		$GLOBALS['STDIN'] = fopen("php://stdin", "r");
	$line = fgets($GLOBALS['STDIN'], $length);
	return trim($line);
}

/*
	Parameters
*/
/////
$default = "has many";
echo "Association type ($default) : ";
$entered = read();
$type = $entered ? $entered : $default;
if ($type != "belongs to" && $type != "has many")
	die("Unknown association type.");

/////
echo "Class name : ";
$class_name = read();

/////
$default = rdg_tablename_of_classname($class_name);
$default = substr($default, 0, strlen($default)-1).".class.php";
echo "Model file name ($default) : ";
$entered = read();
$model_file = $entered ? $entered : $default;

/////
echo "Towards class : ";
$FOREIGN_CLASS_NAME = read();

/////
$default = rdg_tablename_of_classname($FOREIGN_CLASS_NAME);
if ($type == "belongs to")
	$default = substr($default, 0, strlen($default)-1);
echo "Association name ($default) : ";
$entered = read();
$ASSOCIATION_NAME = $entered ? $entered : $default;

/////
if ($type == "belongs to")
	$default = $ASSOCIATION_NAME."_id";
else
	$default = substr($ASSOCIATION_NAME, 0, strlen($ASSOCIATION_NAME)-1)."_id";
echo "Foreign key ($default) : ";
$entered = read();
$FOREIGN_KEY = $entered ? $entered : $default;


/*
	Prepare source code
*/
$needle = array(
	"<?php\n",
	"?>",
	"{{ASSOCIATION_NAME}}",
	"{{FOREIGN_CLASS_NAME}}",
	"{{FOREIGN_KEY}}"
);

$replacement = array(
	"",
	"",
	$ASSOCIATION_NAME,
	$FOREIGN_CLASS_NAME,
	$FOREIGN_KEY
);


if ($type == "belongs to")
	$template = TEMPLATES_DIR."belongs_to.php";
else
	$template = TEMPLATES_DIR."has_many.php";

$template_contents = file_get_contents($template);
if (! $template_contents)
	die("ERROR : Can't find template file '$template'.\n");

$template_contents = str_replace($needle, $replacement, $template_contents);


/*
	Get model
*/
$model_file = SCRIPTS_DIR."../models/$model_file";
$contents = file_get_contents($model_file);
if (! $contents)
	die("ERROR : Can't find model file '$model_file'.\n");

/*
	Update model
*/
$needle = "\t/****************************************************************************
\t\tAssociations
\t****************************************************************************/\n";
$i = strpos($contents, $needle);
if ($i === false)
{
$needle = "\t/****************************************************************************
\t\tRelations
\t****************************************************************************/\n";
	$i = strpos($contents, $needle);
}
if ($i === false)
{
	$needle = "{\n";
	$i = strpos($contents, $needle);
}
if ($i === false)
	die("Incorrect model file");

$cut = $i + strlen($needle);
$begin = substr($contents, 0, $cut);
$end =  substr($contents, $cut);
$contents = $begin . $template_contents . $end;

$f = fopen($model_file, "w");
if (! $contents)
	die("ERROR : Can't open model file '$model_file' for writing.\n");
fwrite($f, $contents);
fclose($f);
?>