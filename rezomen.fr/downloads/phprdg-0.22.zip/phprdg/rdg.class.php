<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**

	RDG représente un enregistrement d'une table mysql. Le but de cette classe est
	de factoriser certaines opérations courantes telles que le chargement et
	l'enregistrement de l'objet, la gestion des erreurs suite à validation d'un
	formulaire, et les appels des callbacks (fonctions appelées automatiquement
	lors de certaines actions, exemples : after_update(), before_destroy()).

	Chaque objet de la classe RDG est associé (par la méthode meta()) à un objet
	de la classe RDGMeta, qui représente la table (et non un enregistrement de la
	table).

	Plus d'informations sur le design-pattern RDG (Row Data Gateway) :
		http://www.martinfowler.com/eaaCatalog/rowDataGateway.html

*/
abstract class RDG
{
	/****************************************************************************
		Stockage des instances de RDGMeta, passée grâce à la méthode abstraite
		meta(). Cf. le fichier README.txt.
	****************************************************************************/
	private static $_meta_instances = array();

	/**
		Ajoute un objet RDGMeta à la liste des objets RDGMeta de l'application.
			@param	RDGMeta	Objet RDGMeta à ajouter.
	*/
	protected static function add_meta(RDGMeta $meta)
	{
		self::$_meta_instances[$meta->class_name()] =& $meta;
	}

	/**
		Indique s'il existe un objet RDGMeta associé à la classe spécifiée.
			@param	string	Nom de la classe.
			@return	boolean
	*/
	protected static function is_meta($class_name)
	{
		return array_key_exists($class_name, self::$_meta_instances);
	}

	/**
		Rend l'objet RDGMeta associé à la classe spécifiée, s'il existe (NULL sinon).
			@param	string	Nom de la classe.
			@param	RDGMeta	Objet RDGMeta associé.
	*/
	protected static function get_meta($class_name)
	{
		if (! self::is_meta($class_name))
			return null;
		return self::$_meta_instances[$class_name];
	}

	/**
		Fonction à définir dans la classe fille (cf. README.txt).
			@return	RDGMeta	Objet de la classe RDGMeta associé à l'objet RDG courant.
	*/
	abstract public static function meta();

	/****************************************************************************
		Constructeur
	****************************************************************************/
	/**
		Instancie un objet. Si $attributes n'est pas spécifié, l'objet est instancié
		avec des valeurs par défaut.
			@param	array	Tableau associatif attribut => valeur.
	*/
	public function __construct($attributes = null)
	{
		$this->_attributes = $this->meta()->default_values();
		if ($attributes)
			$this->update_attributes($attributes);
	}

	/****************************************************************************
		Attributs : accesseurs en lecture et écriture.
	****************************************************************************/
	// Tableau associatif essentiel : attribut => valeur.
	private $_attributes = array();

	/**
		Surcharge de membres : c'est cette fonction qui est appelée quand on écrit
		$objet->$attribute;
			@param	string	Nom d'attribut.
			@return	mixed	Valeur associée.
	*/
	public function __get($attribute)
	{
		if (! $this->meta()->is_defined_attribute($attribute))
			throw new RDGExceptionUnknownAttribute(get_class($this), $attribute);
		return $this->_attributes[$attribute];
	}

	/**
		Surcharge de membres : c'est cette fonction qui est appelée quand on écrit
		$objet->$attribute = $value;
			@param	string	Nom d'attribut.
			@param	mixed	Valeur à affecter.
	*/
	public function __set($attribute, $value)
	{
		if (! $this->meta()->is_defined_attribute($attribute))
			throw new RDGExceptionUnknownAttribute(get_class($this), $attribute);

		// Suppression des erreurs liées à cet attribut (les erreurs éventuelles
		// concernaient la précédente valeur de l'attribut). L'utilisateur devra
		// penser à valider à nouveau !
		$this->flush_errors_on($attribute);

		if ($value === '' && $this->meta()->null_allowed($attribute))
			$value = null;

		// Typecasting
		if ($this->meta()->attribute_type($attribute) == 'date')
		{
			$value = $this->typecast_date($attribute, $value);
		}

		$this->_attributes[$attribute] = $value;
	}

	/**
		Met à jour un ensemble d'attributs en une seule fois.
		Si une clé ne correspond pas à un attribut "réel", on l'enregistre en
		tant que "pseudo attribut".
			@param	array	Tableau associatif des attributs à mettre à jour.
	*/
	public function update_attributes($attributes)
	{
		foreach ($attributes as $attribute => $value)
		{
			if ($this->meta()->is_defined_attribute($attribute))
				$this->$attribute = $value;
			else
				$this->_pseudo_attributes[$attribute] = $value;
		}
	}

	private $_pseudo_attributes = array();

	/**
		Récupération d'un pseudo attribut (s'il n'est pas définit, on cherche alors
		dans les attributs normaux).
			@param	string	Nom d'attribut (pseudo ou normal).
			@return	mixed	Valeur associée.
	*/
	public function get_pseudo($attribute)
	{
		if (array_key_exists($attribute, $this->_pseudo_attributes))
			return $this->_pseudo_attributes[$attribute];
		else
			return $this->$attribute;
	}

	/****************************************************************************
		Transtypage. Exemple : une date est stockée par mysql au format YYYY-MM-DD.
		Si dans l'application on utilise préférentiellement le format DD/MM/YYYY,
		il faut faire la translation.
	****************************************************************************/
	private $_before_typecast = array();

	/**
		Rend la valeur avant transtypage d'un attribut, si elle existe.
			@param	string	Nom d'un attribut.
			@return	mixed	Valeur non transtypée si elle existe, sinon valeur courante
				de l'attribut.
	*/
	public function before_typecast($attribute)
	{
		if (array_key_exists($attribute, $this->_before_typecast))
			return $this->_before_typecast[$attribute];
		else
			return $this->$attribute;
	}

	/**
		Réalise le transtypage d'une date. La fonction rdg_typecast_date est à
		définir dans environment.php.
	*/
	private function typecast_date($attribute, $value)
	{
		$this->_before_typecast[$attribute] = $value;
		if (! $value)
			return null;

		$typecasted_value = rdg_typecast_date($value);
		if ($typecasted_value === null)
		{
			$this->add_error_on($attribute, RDG_TYPECAST_ERROR);
			return $value;
		}
		else
		{
			return $typecasted_value;
		}
	}


	/****************************************************************************
		Gestion des erreurs.

		On peut ajouter des messages d'erreurs, en les associant éventuellement
		à une clé, qui est généralement un attribut (mais pas obligatoirement).
		On utilise ensuite des fonctions permettant de savoir s'il y a des erreurs,
		de récupérer la liste d'erreurs, ...
	****************************************************************************/
	private $_errors = array(); // Tableau associatif, à chaque clé est associé
															// un tableau de messages d'erreur. Les clés sont
															// généralement des noms d'attributs (mais pas obligatoirement).
															// Par convention, la clé 0 représente une liste d'erreurs
															// générales, liées à rien en particulier.

	/**
		Indique s'il existe au moins une erreur.
			@return	boolean
	*/
	public function is_error()
	{
		foreach($this->_errors as $attr => $errors)
		{
			if (! empty($errors))
				return true;
		}
		return false;
	}

	/**
		Indique s'il existe au moins une erreur sur une clé spécifiée.
			@param	string	Clé.
			@return	boolean
	*/
	public function is_error_on($key)
	{
		if (array_key_exists($key, $this->_errors) && ! empty($this->_errors[$key]))
			return true;
		else
			return false;
	}

	/**
		Ajoute un message d'erreur sur aucune clé en particulier.
			@param	string	$message
	*/
	public function add_error($message)
	{
		if (! array_key_exists(0, $this->_errors))
			$this->_errors[0] = array();
		if (! in_array($message, $this->_errors[0]))
			$this->_errors[0][] = $message;
	}

	/**
		Ajoute un message d'erreur sur une clé spécifiée.
			@param	string	$key
			@param	string	$message
	*/
	public function add_error_on($key, $message)
	{
		if (! array_key_exists($key, $this->_errors))
			$this->_errors[$key] = array();
		if (! in_array($message, $this->_errors[$key]))
			$this->_errors[$key][] = $message;
	}

	/**
		Supprime les erreurs liées à une clé donnée.
			@param	string	$key
	*/
	public function flush_errors_on($key)
	{
		$this->_errors[$key] = array();
	}

	/**
		Rend la liste de toutes les erreurs.
			@return	array
	*/
	public function errors()
	{
		return $this->_errors;
	}

	/**
		Rend la liste de toutes les erreurs liées à une clé donnée.
			@param	string	$key
			@return	array
	*/
	public function errors_on($key)
	{
		if (! array_key_exists($key, $this->_errors))
			return array();
		return $this->_errors[$key];
	}

	/**
		Rend la liste de toutes les erreurs non affectées à une clé.
			@return	array
	*/
	public function errors_base()
	{
		if (! array_key_exists(0, $this->_errors))
			return array();
		return $this->_errors[0];
	}

	/**
		Rend la liste de toutes les erreurs affectées à une clé.
			@return	array
	*/
	public function errors_non_base()
	{
		$r = array();
		foreach ($this->_errors as $key => $errors)
		{
			if ($key != 0)
				$r[$key] = $errors;
		}
		return $this->_errors;
	}

	/****************************************************************************
		Validation
	****************************************************************************/
	/**
		Effectue la validation d'un enregistrement (remplissage du tableau des
		erreurs).
			@return	void	Cette fonction ne retourne rien.

		Cette fonction est destinée à être redéfinie dans la classe fille, mais pas
		à être appelée (utiliser la méthode is_valid). La méthode validation a pour
		but de permettre au développeur d'ajouter des spécifications sur la classe
		(exemple : unicité d'un attribut, format d'une chaîne, ...) et d'ajouter
		des erreurs à l'objet s'il ne répond pas à ces spécifications.
		L'appel de la méthode is_valid() appele validation() (et les callbacks) et
		regarde ensuite la liste des erreurs pour répondre TRUE ou FALSE.
	*/
	protected function validation()
	{

	}

	/**
		Indique si un enregistrement est valide.
	*/
	public function is_valid()
	{
		$this->before_validation();
		$this->validation();
		return !$this->is_error();
	}

	/****************************************************************************
		Callbacks.

		Ce sont des fonctions à définir si besoin dans la classe fille. Elles sont
		appelées automatiquement, par exemple avant la validation pour
		before_validation() (utile pour rendre l'objet tout propre avant de le
		checker).

		Elles ne sont pas censées renvoyer quelque chose.

		Note : "after_create" (ou "after_update") est appelé AVANT after_save
	****************************************************************************/
	protected function before_validation() { }

	protected function before_create()   { }
	protected function before_update()   { }
	protected function before_save()   { }
	protected function after_create() { }
	protected function after_update() { }
	protected function after_save()   { }

	protected function before_destroy() { }
	protected function after_destroy() { }

	/****************************************************************************
		Insertion, sauvegarde, suppression
	****************************************************************************/
	/**
		Insère dans la base de données un nouvel enregistrement, ou met à jour
		l'enregistrement (si l'objet est déjà issu de la base de données) en
		vérifiant avant s'il est valide. Les callbacks sont appelés.
			@return	boolean	TRUE si l'objet a été enregistré correctement, FALSE si
				l'objet n'est pas valide.
	*/
	public function save()
	{
		if (! $this->is_valid())
			return false;
		return $this->save_without_validation();
	}

	/**
		Insère dans la base de données un nouvel enregistrement, ou met à jour
		l'enregistrement (si l'objet est déjà issu de la base de données), SANS
		vérifier qu'il est valide. Les callbacks sont appelés.
			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function save_without_validation()
	{
		$this->before_save();
		if ($this->id)
			$this->update();
		else
			$this->create();
		$this->after_save();
		return true;
	}

	/**
		Insère dans la base de données un nouvel enregistrement, ou met à jour
		l'enregistrement (si l'objet est déjà issu de la base de données), SANS
		vérifier qu'il est valide et SANS appeler les callbacks.
			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function save_without_callbacks()
	{
		if ($this->id)
			return $this->update_without_callbacks();
		else
			return $this->create_without_callbacks();
	}

	/**
			@return	string	Clause SET de la requête d'insertion/mise-à-jour.
	*/
	private function subquery()
	{
		$r = "";
		foreach ($this->_attributes as $key => $value)
		{
			if ($key == $this->meta()->primary_key())
				continue;

			if ($r != "")
				$r .= ", ";

			$r .= rdg_p2($key)." = ".rdg_p($value);
		}
		return $r;
	}

	/**
		Met à jour l'enregistrement dans la base de données SANS vérifier qu'il est
		valide. Les callbacks sont appelés.

		Si l'objet n'est pas issu d'un enregistrement de la base de données, une
		exception est levée.

			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function update()
	{
		$this->before_update();
		$this->update_without_callbacks();
		$this->after_update();
		return true;
	}

	/**
		Met à jour l'enregistrement dans la base de données SANS vérifier qu'il est
		valide et SANS appeler les callbacks.

		Si l'objet n'est pas issu d'un enregistrement de la base de données, une
		exception est levée.

			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function update_without_callbacks()
	{
		$primary_key = $this->meta()->primary_key();
		$query = "UPDATE `".$this->meta()->table_name()."` SET ".$this->subquery()." WHERE ".rdg_p2($primary_key)." = ".$this->$primary_key;

		if (! mysql_query($query, $this->meta()->link_identifier()))
			throw new RDGExceptionMySQL(mysql_error($this->meta()->link_identifier()), $query);

		return true;
	}

	/**
		Insère un nouvel enregistrement correspondant à l'objet courant dans la base
		de données SANS vérifier qu'il est valide. Les callbacks sont appelés.

		Si la clé primaire n'est pas précisée mais qu'elle dispose de l'auto
		incrément, il n'y aura pas de problème. De même, si elle est précisée et
		qu'aucun autre enregistrement ne possède la même clé, il n'y aura pas non
		plus de problème. Sinon, une exception sera levée.

			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function create()
	{
		$this->before_create();
		$this->create_without_callbacks();
		$this->after_create();
		return true;
	}

	/**
		Insère un nouvel enregistrement correspondant à l'objet courant dans la base
		de données SANS vérifier qu'il est valide et SANS appeler les callbacks.

		Si la clé primaire n'est pas précisée mais qu'elle dispose de l'auto
		incrément, il n'y aura pas de problème. De même, si elle est précisée et
		qu'aucun autre enregistrement ne possède la même clé, il n'y aura pas non
		plus de problème. Sinon, une exception sera levée.

			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function create_without_callbacks()
	{
		$query = "INSERT INTO `".$this->meta()->table_name()."` SET ".$this->subquery();
		if (! mysql_query($query, $this->meta()->link_identifier()))
			throw new RDGExceptionMysql(mysql_error($this->meta()->link_identifier()), $query);

		$primary_key = $this->meta()->primary_key();
		if (! $this->$primary_key)
			$this->$primary_key = mysql_insert_id();

		return true;
	}

	/**
		Supprime l'enregistrement correspondant à l'objet en appelant les callbacks.
			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function destroy()
	{
		$this->before_destroy();
		$r = $this->destroy_without_callbacks();
		if (! $r)
			return false;
		$this->after_destroy();
		return true;
	}

	/**
		Supprime l'enregistrement correspondant à l'objet SANS appeler les
		callbacks.
			@return	boolean	TRUE si l'objet a été enregistré correctement.
	*/
	public function destroy_without_callbacks()
	{
		$primary_key = $this->meta()->primary_key();
		if (! $this->$primary_key)
			return false;

		$query = "DELETE FROM `".$this->meta()->table_name()."` WHERE ".rdg_p2($primary_key)." = ".rdg_p($this->$primary_key);
		if (! mysql_query($query, $this->meta()->link_identifier()))
			throw new RDGExceptionMysql(mysql_error($this->meta()->link_identifier()), $query);

		return true;
	}
}
?>
