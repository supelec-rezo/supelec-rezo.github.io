<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**
	Fichier de configuration de PhpRDG.
*/

/**
	Paramètres des connexions à la base de données.
	(Note : $RDG_CONNECTIONS est utilisé dans le constructeur de RDGMeta).

	Vous pouvez également définir vous-même la variable $RDG_CONNECTIONS dans un
	autre fichier de votre application.
*/
if (! isset($RDG_CONNECTIONS))
{
	$RDG_CONNECTIONS = array(
		// Connexion par défaut des classes (si aucune n'est précisée).
		'default' => array(
									"host" => "localhost",
									"user" => "my_user",
									"pass" => "my_password",
									"base" => "my_database",
								)
	);
}
?>