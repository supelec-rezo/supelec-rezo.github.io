<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**

	Fonctions dépendant de l'environnement.

	Ce fichier contient des fonctions qui sont utilisées par PhpRDG. Elles
	offrent une fonctionnalité dépendant de l'environnement particulier dans
	lequel PhpRDG est utilisé (exemple : le langage).

	Si le comportement par défaut ne correspond pas à vos	besoins, vous pouvez
	les adapter directement dans ce fichier, ou bien les réecrire dans un autre
	de vos fichiers.

*/


if (! function_exists("rdg_typecast_date"))
{
	/**
		Translation d'une date écrite dans un format quelconque en une date au
		format compréhensible par mysql.
			@param	string	Date dans un format quelconque utilisé dans l'application
				(par exemple DD/MM/YYYY) ou au format mysql (YYYY-MM-DD). La fonction doit
				être capable de repérer quel est le format d'entrée.
			@return	string	La même date, au format mysql (YYYY-MM-DD), ou NULL si la
				date de départ est incorrecte (mauvais format ou 30 février...).
		Note : cette fonction est appelée dans la méthode "typecast_date" de la classe
		RDG.
	*/
	function rdg_typecast_date($value)
	{
		// Il faut filtrer pour savoir quel est le format de $value.
		if (ereg("^([0-9]{4})\-([0-9]{2})\-([0-9]{2})$", $value, $regs)) // Format mysql (américain)
		{
			$year = intval($regs[1]);
			$month = intval($regs[2]);
			$day = intval($regs[3]);
			if (! checkdate($month, $day, $year))
				return null;
			else
				return $value;
		}
		elseif (ereg("^([0-9]{1,2})/([0-9]{1,2})/([0-9]{2}|[0-9]{4})$", $value, $regs)) // Format français
		{
			if (strlen($regs[3]) == 2)
				$year = intval("20".$regs[3]);
			else
				$year = intval($regs[3]);
			$month = intval($regs[2]);
			$day = intval($regs[1]);

			if (! checkdate($month, $day, $year))
				return null;
			else
				return $year . "-" . ($month < 10 ? '0' . $month : $month) . "-" . ($day < 10 ? '0'.$day : $day);
		}
		else
			return null;
	}
}

/**
	En cas d'erreur de transtypage, la chaîne utilisée pour décrire l'erreur.
*/
define("RDG_TYPECAST_ERROR", "est invalide");

/**
	Rend le nom de la table mysql correspondant à la classe.
		@param	string	Nom de la classe (exemple : SuperLivre).
		@return	string	Nom de la table (exemple : super_livres).
	Note : cette fonction est appelée dans le constructeur de RDGMeta.
*/
if (! function_exists("rdg_tablename_of_classname"))
{
	function rdg_tablename_of_classname($classname)
	{
		$return = "";
		for ($i = 0; $i < strlen($classname); $i ++)
		{
			$chr = $classname[$i];
			$ord = ord($chr);
			if ($ord >= 65 && $ord <= 90) // S'il s'agit d'une majuscule
			{
				$ord += 32;
				if ($i > 0)
					$return .= '_';
				$return .= chr($ord);
			}
			else
				$return .= $chr;
		}
		$return .= "s";
		return $return;
	}
}
?>
