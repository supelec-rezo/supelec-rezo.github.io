<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et conditions.

*/

/**
  Fichier permettant l'inclusion de PHP View dans un projet.
*/

require "view.class.php";
require "utils.inc.php";
?>
