<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et conditions.

*/

/**
	Rend la valeur d'un paramètre passé à une page. S'il n'est pas trouvé, une
	exception est levée.
		@param	string	Nom du paramètre
		@return	string	Valeur du paramètre
*/
function param($name)
{
	if (isset($_GET[$name]))
		$r = $_GET[$name];
	elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST[$name]))
		$r = $_POST[$name];
	else
		throw new Exception("Parameter '$name' required.");

	if (is_array($r))
	{
		$return = array();
		foreach ($r as $k => $v)
			$return[$k] = stripslashes($v);
		return $return;
	}
	else
		return stripslashes($r);
}

/**
	Indique si un paramètre a été passé à la page.
		@param	string	Nom du paramètre
*/
function is_param($name)
{
	return isset($_GET[$name])
		|| ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST[$name]));
}
?>