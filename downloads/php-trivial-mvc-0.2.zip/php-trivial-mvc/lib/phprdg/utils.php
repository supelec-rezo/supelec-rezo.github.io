<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**
	Fonctions utilisées par PhpRDG.
*/

/**
	Connexion à la base de données.
	Remarque : il n'est pas nécessaire de fermer les connexions ouvertes (voir la
	documentation de la fonction mysql_close() de PHP).
		@param	string	Hôte (ip ou nom).
		@param	string	Utilisateur.
		@param	string	Mot de passe.
		@param	string	Base de données par défaut.
		@return	link_identifier
*/
function rdg_connect($host, $user, $pass, $base)
{
	$r = mysql_connect($host, $user, $pass);
	if (! $r)
		throw new RDGExceptionMySQL(mysql_error());

	if (! mysql_select_db($base, $r))
		throw new RDGExceptionMySQL(mysql_error());

	$query = "SET NAMES 'utf8'";
	if (! mysql_query($query, $r))
		throw new RDGExceptionMySQL(mysql_error(), $query);

	return $r;
}

/**
	Rend une valeur prête à être insérée dans une requête SQL sans risque	de
	faille par injection. Utilisation classique :
	"SELECT * FROM users WHERE login = ".rdg_p($login)." AND pass = ".rdg_p($pass)

	Mnémo : la lettre "p" du nom de la fonction est l'initiale de "protect".

		@param	mixed	Valeur sans guillemets protecteurs et sans caractères échappés.
		@param	string	Chaîne prête à être insérée dans une requête SQL.
*/
function rdg_p($str)
{
	if ($str === null)
		return "NULL";
	return "\"" . mysql_real_escape_string($str) . "\"";
}

/**
	Rend une valeur prête à être insérée dans une requête SQL sans risque	de
	faille par injection, pour les noms de table et d'attribut. Utilisation
	classique :
	"SELECT * FROM ".rdg_p2($table)." WHERE ".rdg_p2($attribut)." = 'truc'".
		@param	mixed	Nom sans quotes protecteurs et sans caractères échappés.
		@param	string	Nom prêt à être inséré dans une requête SQL.
*/
function rdg_p2($str)
{
	return "`" . mysql_real_escape_string($str) . "`";
}
?>
