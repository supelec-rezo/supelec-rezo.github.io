<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**

	RDGMeta représente une table mysql (donc un seul objet de type RDGMeta
	par table	de la base de données). Les objets RDGMeta sont stockés dans
	l'attribut statique $_meta_instances de la classe RDG.

	RDGMeta contient des informations sur la table (son nom, les attributs
	correspondants, ...) et sur la manière dont l'application souhaite
	s'interfacer avec (le nom de la classe faisant l'abstraction, l'ordre par
	défaut des élements, ...).

	Enfin, RDGMeta fournit des "finders" (find, find_all, count, delete_all, ...),
	méthodes publiques permettant d'effectuer des opérations ou des recherches
	sur plusieurs entrées de la table à la fois.

	Plus d'informations sur le design-pattern RDG (Row Data Gateway) :
		http://www.martinfowler.com/eaaCatalog/rowDataGateway.html

*/
class RDGMeta
{
	/****************************************************************************
		Constructeur, attributs qui doivent être passés au constructeur, et
		accesseurs correspondant.
	****************************************************************************/
	private $class_name;
	private $table_name;
	private $primary_key;
	private $connection_key;
	private $link_identifier;
	private static $link_identifiers = array();

	/**
		Construction d'un objet RDGMeta faisant l'association entre une classe et
		une	table.
			@param	string	Nom de la classe, il doit être spécifié.
			@param	string	Nom de la table, il peut être déduit du nom de la classe.
			@param	string	Nom de la clé primaire, par défaut "id".
			@param	string	Clé de la connexion à la base de données (définie dans
				config.php).
	*/
	public function __construct(
		$class_name,
		$table_name = null,
		$primary_key = 'id',
		$connection_key = 'default'
	)
	{
		global $RDG_CONNECTIONS;

		$this->class_name = $class_name;
		if ($table_name)
			$this->table_name = $table_name;
		else
			$this->table_name = rdg_tablename_of_classname($class_name);

		$this->primary_key = $primary_key;

		$this->connection_key = $connection_key;
		if (! array_key_exists($connection_key, self::$link_identifiers))
		{
			$link = rdg_connect($RDG_CONNECTIONS[$connection_key]['host'],
				$RDG_CONNECTIONS[$connection_key]['user'],
				$RDG_CONNECTIONS[$connection_key]['pass'],
				$RDG_CONNECTIONS[$connection_key]['base']);
			self::$link_identifiers[$connection_key] = $link;
		}
		$this->link_identifier = self::$link_identifiers[$connection_key];

		$this->load_attributes();
	}

	/**
		Rend le nom de la classe associée à l'objet RDGMeta. Il doit être défini
		au moment de la construction de l'objet (cf. constructeur).
			@return	string	Nom de la classe associée.
	*/
	public function class_name()
	{
		return $this->class_name;
	}

	/**
		Rend le nom de la table associée à l'objet RDGMeta. Il doit être défini
		au moment de la construction de l'objet (cf. constructeur).
			@return	string	Nom de la table associée.
	*/
	public function table_name()
	{
		return $this->table_name;
	}

	/**
		Rend le nom de la clé primaire. Par défaut, 'id'. Sinon, il doit être défini
		au moment de la construction de l'objet (cf. constructeur).
			@return	string	Nom de la clé primaire de la table associée.
	*/
	public function primary_key()
	{
		return $this->primary_key;
	}

	/**
		Rend la clé de la connexion MySQL associée (définie dans config.php).
			@return	string	Clé de la connexion.
	*/
	public function connection_key()
	{
		return $this->connection_key;
	}

	/**
		Rend l'identifiant de connexion MySQL associée. Il doit être défini au
		moment de la construction de l'objet (cf. constructeur).
			@return	link_identifier	Identifiant de connexion MySQL.
	*/
	public function link_identifier()
	{
		return $this->link_identifier;
	}

	/****************************************************************************
		Configuration générale.
	****************************************************************************/
	private $default_order;

	/**
		Définit l'ordre par défaut des éléments de la table lorsqu'une requête rend
		plusieurs résultats.
			@param  string  Même syntaxe qu'après la clause ORDER BY d'une requête
				SQL. Exemple : "nom asc, prenom asc, age desc".
				ATTENTION : Si vous noms d'attributs sont des variables, protégez contre
				les injections SQL (fonction "rdg_p2" du fichier utils.php).
	*/
	public function set_default_order($default_order)
	{
		$this->default_order = $default_order;
	}

	/****************************************************************************
		Attributs issus de la table, types, valeurs par défaut.
	****************************************************************************/
	private $defined_attributes = array(); // Liste des attributs.
	private $attribute_types = array(); // Tableau associatif : attribut => type (string. Syntaxe MySQL. Exemple : varchar(10)).
	private $default_values = array(); // Tableau associatif : attribut => valeur par défaut (mixed).
	private $null_allowed = array(); // Tableau associatif : attribut => valeur NULL autorisée (booléen).

	/**
		Charge les membres ci-dessus à partir des colonnes de la table.
		Cette méthode est appelée à la construction des objets de la classe
		RDGMeta.
	*/
	private function load_attributes()
	{
		$query = "SHOW COLUMNS FROM ".rdg_p2($this->table_name);
		if (! $r = mysql_query($query, $this->link_identifier))
			throw new RDGExceptionMySQL(mysql_error($this->link_identifier), $query);

		$this->defined_attributes = array();
		$this->attribute_types = array();
		$this->default_values = array();
		$this->null_allowed = array();

		while ($l = mysql_fetch_assoc($r))
		{
			$attribute = $l['Field'];
			$this->defined_attributes[] = $attribute;
			$this->attribute_types[$attribute] = trim($l['Type']);
			$this->default_values[$attribute] = $l['Default'];
			$this->null_allowed[$attribute] = $l['Null'] == 'YES';
		}
	}

	/**
		Indique si un attribut existe.
			@param	string	Nom de l'attribut.
			@return	boolean
	*/
	public function is_defined_attribute($attribute)
	{
		return in_array($attribute, $this->defined_attributes);
	}

	/**
		Rend la liste des attribus définis (hors clé primaire).
			@return	array	Noms des attributs.
	*/
	public function defined_attributes()
	{
		return $this->defined_attributes;
	}

	/**
		Rend le type (syntaxe MySQL) d'un attribut. Lève une exception si l'attribut
		n'existe pas.
			@return	string	Exemple : varchar(10).
	*/
	public function attribute_type($attribute)
	{
		if (! $this->is_defined_attribute($attribute))
			throw new RDGExceptionUnknownAttribute($this->class_name, $attribute);
		return $this->attribute_types[$attribute];
	}

	/**
		Indique si un attribut accepte la valeur NULL. Lève une exception si
		l'attribut n'existe pas.
			@return	boolean
	*/
	public function null_allowed($attribute)
	{
		if (! $this->is_defined_attribute($attribute))
			throw new RDGExceptionUnknownAttribute($this->class_name, $attribute);
		return $this->null_allowed[$attribute];
	}

	/**
		Rend la valeur par défaut d'un attribut. Lève une exception si l'attribut
		n'existe pas.
			@return	string
	*/
	public function default_value($attribute)
	{
		if (! $this->is_defined_attribute($attribute))
			throw new RDGExceptionUnknownAttribute($this->class_name, $attribute);
		return $this->default_values[$attribute];
	}

	/**
		Modifie la valeur par défaut d'un attribut. Lève une exception si l'attribut
		n'existe pas.
			@return	array	Tableau associatif attribut => valeur par défaut.
	*/
	public function set_default_value($attribute, $default_value)
	{
		if (! $this->is_defined_attribute($attribute))
			throw new RDGExceptionUnknownAttribute($this->class_name, $attribute);
		$this->default_values[$attribute] = $default_value;
	}

	/**
		Rend le tableau associatif des valeurs par défaut des attributs.
			@return	array	Tableau associatif attribut => valeur par défaut.
	*/
	public function default_values()
	{
		return $this->default_values;
	}


	/****************************************************************************
		Optionnel - Nom ou description (des attributs normalement, mais on empêche
		pas d'associer un nom ou une description à autre chose).
		Exemple d'utilisation : affichage d'un message d'erreur sous la forme
			$NOM_DE_L'ATTRIBUT." ".$MESSAGE
	****************************************************************************/
	private $attribute_descr = array(); // Tableau associatif : attribut => nom

	/**
		Affecte une petite description à un attribut.
			@param	string  $attribute
			@param	string  $description
	*/
	public function set_attribute_descr($attribute, $description)
	{
		$this->attribute_descr[$attribute] = $description;
	}

	/**
		Rend la petite description d'un attribut si elle a été affectée grâce à la
		méthode set_attribute_desc ou le nom de l'attribut sinon.
			@param	string	$attribute
			@return	string
	*/
	public function attribute_descr($attribute)
	{
		if (array_key_exists($attribute, $this->attribute_descr))
			return $this->attribute_descr[$attribute];
		else
			return $attribute;
	}


	/****************************************************************************
		Finders
	****************************************************************************/
	/**
		Rend un tableau d'objets correspondants à la requête SQL passée.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Requête SQL complète ("SELECT * FROM ...").
			@return	array	Tableau d'objets correspondants.
	*/
	public function find_by_sql($query)
	{
		if (! $r = mysql_query($query, $this->link_identifier))
			throw new RDGExceptionMySQL(mysql_error($this->link_identifier), $query);

		$objects = array();
		while ($attributes = mysql_fetch_assoc($r))
			$objects[] = new $this->class_name($attributes);

		return $objects;
	}

	/**
		Rend un tableau d'objets correspondants aux critères passés.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Clause WHERE d'une requête SQL.
				Exemple : "nom = 'truc' AND bidule > 5"
			@param	string	Clause ORDER BY d'une requête SQL.
				Exemple : "bidule desc". Si pas fourni, l'ordre par défaut pour cette
				table sera utilisé.
			@return	array	Tableau d'objets correspondants.
	*/
	public function find_all($where = null, $order_by = null)
	{
		if ($where)
			$where = "WHERE $where";
		else
			$where = "";

		if ($order_by)
			$order_by = "ORDER BY $order_by";
		elseif ($this->default_order)
			$order_by = "ORDER BY $this->default_order";
		else
			$order_by = "";

		$query = "SELECT * FROM ".rdg_p2($this->table_name)." ".$where." ".$order_by;

		return $this->find_by_sql($query);
	}

	/**
		Rend le premier objet correspondants aux critères passés, ou NULL si aucun
		ne correspond.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Clause WHERE d'une requête SQL.
				Exemple : "nom = 'truc' AND bidule > 5"
			@param	string	Clause ORDER BY d'une requête SQL.
				Exemple : "bidule desc". Si pas fourni, l'ordre par défaut pour cette
				table sera utilisé.
			@return	mixed	Premier objet correspondant.
	*/
	public function find_one($where = null, $order_by = null)
	{
		$r = $this->find_all($where, $order_by);
		if (sizeof($r) > 0)
			return $r[0];
		else
			return null;
	}

	/**
		Rend l'enregistrement correspondant dont la clé primaire est égale au
		paramètre passé. Lève une exception si aucun ne correspond.
			@param	mixed	Valeur de la clé primaire de recherchée.
			@return	mixed	Objet correspondant.
	*/
	public function find($id)
	{
		$object = $this->find_one(rdg_p2($this->primary_key)." = ".rdg_p($id));

		if (! $object)
			throw new RDGExceptionNotFound($this->class_name, $id);

		return $object;
	}

	/**
		Rend un tableau associatif (id) => (valeur d'un attribut) pour les
		enregistrements correspondants aux critères passés.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Attribut recherché. Exemple : "nom"
			@param	string	Clause WHERE d'une requête SQL.
				Exemple : "prenom = 'truc' AND bidule > 5"
			@param	string	Clause ORDER BY d'une requête SQL.
				Exemple : "bidule desc". Si pas fourni, l'ordre par défaut pour cette
				table sera utilisé.
			@return	array	Tableau associatif cle primaire => attribut recherché.
	*/
	public function find_id_value_array($attribute, $where = null, $order_by = null)
	{
		if ($where)
			$where = "WHERE $where";
		else
			$where = "";

		if ($order_by)
			$order_by = "ORDER BY $order_by";
		elseif ($this->default_order)
			$order_by = "ORDER BY $this->default_order";
		else
			$order_by = "";

		$query = "SELECT ".rdg_p2($this->primary_key).",".rdg_p2($attribute)." FROM ".rdg_p2($this->table_name)." ".$where." ".$order_by;
		if (! $r = mysql_query($query, $this->link_identifier))
			throw new RDGExceptionNotFound(mysql_error($this->link_identifier), $query);

		$assoc = array();
		while ($l = mysql_fetch_row($r))
			$assoc[$l[0]] = $l[1];

		return $assoc;
	}

	/**
		Compte le nombre d'enregistrements correspondants au critère passé.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
		@param	string	Clause WHERE d'une requête SQL.
			Exemple : "nom = 'truc' AND bidule > 5"
		@return	int	Nombre d'enregistrements correspondant.
	*/
	public function count($where = null)
	{
		if ($where)
			$where = "WHERE $where";
		else
			$where = "";

		$query = "SELECT COUNT(".rdg_p2($this->primary_key).") FROM ".rdg_p2($this->table_name)." ".$where;

		if (! $r = mysql_query($query, $this->link_identifier))
			throw new RDGExceptionMySQL(mysql_error($this->link_identifier), $query);

		$l = mysql_fetch_row($r);
		return intval($l[0]);
	}

	/**
		Indique si un enregistrement correspond à la clé primaire passée en
		argument.
			@param	mixed	Valeur de la clé primaire recherchée.
			@return	boolean
	*/
	public function exists($id)
	{
		return $this->count(rdg_p2($this->primary_key)." = ".rdg_p2($id)) > 0;
	}

	/**
		Supprime tous les enregistrements correspondants aux critères passés.
		Les objets ne sont pas instanciés, les callbacks ne sont donc pas appelés.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Clause WHERE d'une requête SQL.
				Exemple : "nom = 'truc' AND bidule > 5".
	*/
	public function delete_all($where = null)
	{
		if ($where)
			$where = "WHERE $where";
		else
			$where = "";

		$query = "DELETE FROM ".rdg_p2($this->table_name)." ".$where;
		if (! $r = mysql_query($query, $this->link_identifier))
			throw new RDGExceptionMySQL(mysql_error($this->link_identifier), $query);

		return true;
	}


	/**
		Supprime tous les enregistrements correspondants aux critères passés, en
		les instanciants au préalables (les callbacks sont appelés).
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Clause WHERE d'une requête SQL.
				Exemple : "nom = 'truc' AND bidule > 5".
	*/
	public function destroy_all($where = null)
	{
		$objects = $this->find_all($where);
		foreach ($objects as $o)
		  $o->destroy();

		return true;
	}

	/**
		Met à jour tous les enregistrements correspondants à la clause WHERE
		spécifiée dans le paramètre $where avec les valeurs spécifiées dans le
		paramètre $set.
		Les objets ne sont pas instanciés, les callbacks ne sont donc pas appelés.
		ATTENTION : Protégez vos requêtes contre les injections SQL grâce aux
		fonctions "rdg_p" et "rdg_p2" (cf. fichier utils.php).
			@param	string	Clause SET d'une requête SQL.
				Exemple : "nom = 'truc5', bidule = 96"
			@param	string	Clause WHERE d'une requête SQL.
				Exemple : "nom = 'truc' AND bidule > 5"
	*/
	public function update_all($set, $where = null)
	{
		$set = "SET $set";

		if ($where)
			$where = "WHERE $where";
		else
			$where = "";

		$query = "UPDATE ".rdg_p2($this->table_name)." ".$set." ".$where;
		if (! $r = mysql_query($query, $this->link_identifier))
			throw new RDGExceptionMySQL(mysql_error($this->link_identifier), $query);

		return true;
	}
}
?>
