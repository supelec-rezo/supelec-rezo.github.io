<?php
if (! defined('CONTROLLER')) exit;

/**
	Exemple de template.
*/
?>

<h2>Introduction</h2>

<p>Bienvenue !</b>