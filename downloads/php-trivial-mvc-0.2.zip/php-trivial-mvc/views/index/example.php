<?php
if (! defined('CONTROLLER')) exit;

/**
	Exemple de template.
*/
?>

<h2>Exemple simple</h2>

<form method="post" action="index.php?a=example2">
	<p>Hello. What's your name ?</p>

	<p><input type="text" name="name" id="name" value="" /></p>

	<p><input type="submit" name="submit" id="submit" value="OK" /></p>
</form>