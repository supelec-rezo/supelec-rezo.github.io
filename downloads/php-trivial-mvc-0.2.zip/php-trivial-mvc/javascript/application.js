/*
	Fonctions Javascripts. Ce fichier est appelé par le layout par défaut (cf. le
	fichier layouts/application.layout.php).
*/