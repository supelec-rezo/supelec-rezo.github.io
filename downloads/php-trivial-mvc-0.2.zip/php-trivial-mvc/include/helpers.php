<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et conditions.

*/
if (! defined('CONTROLLER')) exit; // On empêche l'exécution de ce fichier hors des contrôleurs.

/**
	Affichage propre d'une chaîne de caractères pouvant contenir des caractères
	spéciaux.
*/
function h($str)
{
	return stripslashes(htmlentities($str, ENT_QUOTES, "UTF-8"));
}

/**
	Permet d'utiliser la méthode POST (plutôt que GET) depuis un lien hypertexte,
	après demande de confirmation.

	Exemple d'utilisation :
		<a href="bidule.php" onclick="<?php echo confirm_onclick(); ?>" />Go !</a>

*/
function confirm_onclick($confirm_text = "Êtes-vous sûr ?")
{
	return "if (confirm('".str_replace("'", "\'", $confirm_text)."')) { var f = document.createElement('form'); f.style.display = 'none'; this.parentNode.appendChild(f); f.method = 'POST'; f.action = this.href;f.submit(); };return false;";
}

/**
	Affichage sympathique des erreurs enregistrées sur des objets PHPRDG.
*/
function error_messages_for($object)
{
	if ($object->is_error())
	{
		echo "<div class='error'>
		<ul>";
		$errors_base = $object->errors_base();
		foreach ($errors_base as $msg)
			echo "<li>$msg</li>";

		$errors = $object->errors_non_base();
		foreach ($errors as $attribute => $errors_on)
			foreach ($errors_on as $msg)
				echo "<li><i>".$object->meta()->attribute_descr($attribute)."</i> $msg.</li>";
		echo "</ul>
		</div>";
	}
}

/**
	Vérifie et transforme une date du format mysql vers le format français.
		@param	string	$sqldate  Une date au format mysql (YYYY-MM-DD)
		@return	string	La date au format français (DD/MM/YYYY).
*/
function date_of_sql($date_sql)
{
	if (! $date_sql || $date_sql == '0000-00-00')
		return null;

	if (! ereg("^([0-9]{4})\-([0-9]{2})\-([0-9]{2})$", $date_sql, $regs))
		return null;

	$year = intval($regs[1]);
	$month = intval($regs[2]);
	$day = intval($regs[3]);

	if (! checkdate($month, $day, $year))
		return null;

	return ($day < 10 ? '0'.$day : $day) . "/" . ($month < 10 ? '0' . $month : $month) . "/" . $year;
}

/**
	Vérifie et transforme une date du format français vers le format mysql.
		@param	string	$sqldate  Une date au format français (DD/MM/YYYY)
		@return	string	La date au format mysql (YYYY-MM-DD).
*/
function sql_of_date($date_fr)
{
	if (! $date_fr)
		return null;

	if (! ereg("^([0-9]{1,2})/([0-9]{1,2})/([0-9]{2}|[0-9]{4})$", $date_fr, $regs))
		return null;

	if (strlen($regs[3]) == 2)
		$year = intval("20".$regs[3]);
	else
		$year = intval($regs[3]);
	$month = intval($regs[2]);
	$day = intval($regs[1]);

	if (! checkdate($month, $day, $year))
		return null;

	return $year . "-" . ($month < 10 ? '0' . $month : $month) . "-" . ($day < 10 ? '0'.$day : $day);
}
?>