<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et conditions.

*/
if (! defined('CONTROLLER')) exit; // On empêche l'exécution de ce fichier hors des contrôleurs.

/**
	Affiche un champ de texte sur le champ $field_name de l'objet $object.
		@param	object	$object	Objet utilisé
		@param	string	$object_post_name	Nom du tableau représentant l'objet, qui sera passé par la méthode POST
		@param	string	$field_name	Nom de l'attribut de l'objet correspondant à ce champ
		@param	array 	$options	Options disponible : size, value, ...
		@param	string	$type	text|password|hidden
*/
function text_field($object, $object_post_name, $field_name, $options = array(), $type = 'text')
{
	if (isset($options['value']))
		$value = $options['value'];
	else
		$value = $object->$field_name;

	$r = "<input type=\"$type\" name=\"".$object_post_name."[$field_name]\" id=\"".$object_post_name."_".$field_name."\" value=\"".h($value)."\"";

	if (isset($options['size']))
		$r .= " size=\"".intval($options['size'])."\"";

	$r .=" />\n";
	return $r;
}

function password_field($object, $object_post_name, $field_name, $options = array())
{
	return text_field($object, $object_post_name, $field_name, $options, 'password');
}

function hidden_field($object, $object_post_name, $field_name, $options = array())
{
	return text_field($object, $object_post_name, $field_name, $options, 'hidden');
}

function date_field($object, $object_post_name, $field_name)
{
	$value = date_of_sql($object->$field_name);
	if (! $value)
		$value = $object->before_typecast($field_name);

	return text_field($object, $object_post_name, $field_name, array('value' => $value, 'size' => 10)) . " <span class='form_help'>(JJ/MM/AAAA)</span>";
}

/**
	@param  array  $list     Tableau associatif id => value.
	@param  array  $options  Options disponible : include_blank, selected, use_keys (utiliser les clés du tableau ou uniquement les valeurs)
*/
function options_for_select($object, $field_name, $list, $options = array())
{
	$use_keys = isset($options['use_keys']) ? $options['use_keys'] : true;

	$r = "";
	if (isset($options['selected']))
		$selected = $options['selected'];
	else
		$selected = $object->$field_name;

	$include_blank = isset($options['include_blank']) ? $options['include_blank'] : true;
	if ($include_blank)
		$r .= "<option value=''></option>\n";

	foreach ($list as $k => $v)
	{
		if (! $use_keys)
			$k = $v;
		$r .= "<option value=\"".h($k)."\"".($selected == $k ? " selected=\"selected\"": "").">".h($v)."</option>\n";
	}

	return $r;
}

/**
	@param  array   $options  Options disponible : value
*/
function check_field($object, $object_post_name, $field_name, $options = array())
{
	if (isset($options['value']))
		$value = $options['value'];
	else
		$value = $object->$field_name;

	$r = "";

	// Pour que les valeurs fausses apparaissent
	$r .= "<input type=\"hidden\" name=\"".$object_post_name."[$field_name]\" id=\"".$object_post_name."_".$field_name."_faux\" value=\"0\" />";

	$r .= "<input type=\"checkbox\" name=\"".$object_post_name."[$field_name]\" id=\"".$object_post_name."_".$field_name."\" value=\"1\"";

	if ($value)
		$r .= " checked=\"checked\"";

	$r .= " />\n";
	return $r;
}
?>
