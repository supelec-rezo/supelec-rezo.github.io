<?php
if (! defined('CONTROLLER')) exit;

/**
	Exemple de layout.
*/

echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
	<head>
		<title>PHP Trivial MVC</title>
		<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="style/application.css" />
		<?php
		// Inclusion de feuilles de style supplémentaires éventuelles
		if (isset($_css_files))
		{
			foreach($_css_files as $css_file)
				echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"style/$css_file\" />";
		}
		?>
		<script src="javascript/application.js" type="text/javascript"></script>
		<?php
		// Inclusion de fichiers de scripts supplémentaires éventuels
		if (isset($_js_files))
		{
			foreach($_js_files as $js_file)
				echo "<script src=\"javascript/$js_file\" type=\"text/javascript\"></script>";
		}
		?>
	</head>
	<body>
		<div id="menu">
			<ul>
				<li class="first"><a href="index.php">Introduction</a></li>
				<li><a href="index.php?a=example">Exemple simple</a></li>
				<li><a href="index.php?a=example_crud">Exemple de CRUD</a> (Create Read Update Delete)</li>
			</ul>
		</div>
		<div id="content">
			<?php
			// Système de passage de valeurs entre pages par l'intermédiaire de la
			// session.
			flash_display(); // Voir le code source dans flash.inc.php
			?>
			<?php echo $_content; ?>
		</div>
	</body>
</html>
