<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**

	Ce fichier permet de générer un modèle, un contrôleur et des vues à partir
	d'une table présente dans la base de données (configurer l'accès à la base
	de données via le fichier "include/config.php").
	
	Il s'exécute en mode console (commande "php" ou "php5"). Pour des raisons
	de sécurité, vous devriez supprimer le dossier "scripts" une fois la phase de
	développement terminée.

*/
if (php_sapi_name() != "cli")
	die("Ce script ne peut être utilisé qu'en ligne de commande.");

define("CONTROLLER", "SCAFFOLD"); // Pour pouvoir utiliser le fichier config.php

define("SCRIPTS_DIR", dirname(__FILE__)."/");
define("TEMPLATES_DIR", SCRIPTS_DIR."templates/scaffold/");

require SCRIPTS_DIR."../include/config.php";
require SCRIPTS_DIR."../lib/phprdg/include.php";

function read($length='255')
{
	if (! isset ($GLOBALS['STDIN']))
		$GLOBALS['STDIN'] = fopen("php://stdin", "r");
	$line = fgets($GLOBALS['STDIN'], $length);
	return trim($line);
}

/*
	Parameters
*/
/////
echo "Class name : ";
$CLASS_NAME = read();

/////
$default = rdg_tablename_of_classname($CLASS_NAME);
echo "Table name ($default) : ";
$entered = read();
$TABLE_NAME = $entered ? $entered : $default;

/////
$default = substr($TABLE_NAME, 0, strlen($TABLE_NAME) - 1);
echo "Singular variable name ($default) : ";
$entered = read();
$VAR_SING = $entered ? $entered : $default;

/////
$default = $VAR_SING."s";
echo "Plurial variable name ($default) : ";
$entered = read();
$VAR_PLUR = $entered ? $entered : $default;

/*
	Get attributes
*/
$meta = new RDGMeta($CLASS_NAME, $TABLE_NAME);
$attributes = $meta->defined_attributes();

// Traitement des associations de type "belongs to". Le tableau ci-dessous
// aura pour index les clés étrangères des associations et pour valeur un
// tableau contenant nom et classe de l'association.

/*
	For each attribute, populate complex template variables
*/
$ATTRIBUTES_TH = "";
$ATTRIBUTES_TD = "";
$ATTRIBUTES_FORM = "";
$ATTRIBUTES_SHOW = "";
$BELONGS_TO_ASSOCIATIONS = "";
$is_first = true;
foreach($attributes as $attribute)
{
	if ($attribute != "id")
	{
		// Recherche des associations
		$is_foreign_key = false;
		if (ereg("^(.+)_id$", $attribute, $regs))
		{
			$default = "y";
			echo "Is '$attribute' a foreign key of a belongs to association ? ($default) : ";
			$entered = read();
			$is_foreign_key = $entered ? $entered : $default;
			$is_foreign_key = $is_foreign_key == "y";
			
			if ($is_foreign_key)
			{
				$default = $regs[1];
				echo "--> Association name ($default) : ";
				$entered = read();
				$association_name = $entered ? $entered : $default;

				$default = ucfirst($regs[1]);
				echo "--> Association foreign class name ($default) : ";
				$entered = read();
				$association_class_name = $entered ? $entered : $default;
				

				$default = "name";
				echo "--> Other class representative attribute ($default) : ";
				$entered = read();
				$association_main_attribute = $entered ? $entered : $default;
				
				
				$association_template_file = SCRIPTS_DIR."templates/associations/belongs_to.php";
				$association_template_contents = file_get_contents($association_template_file);
				if (! $association_template_contents)
					die("ERROR : Can't find template file '$association_template_file'.\n");
				
				$needle = array(
					"<?php\n",
					"?>",
					"{{ASSOCIATION_NAME}}",
					"{{FOREIGN_CLASS_NAME}}",
					"{{FOREIGN_KEY}}"
				);
				
				$replacement = array(
					"",
					"",
					$association_name,
					$association_class_name,
					$attribute
				);
				$BELONGS_TO_ASSOCIATIONS .= str_replace($needle, $replacement, $association_template_contents);
			}
		}

		if ($is_foreign_key)
			$attribute_text = ucfirst($association_name);
		else
			$attribute_text = ucfirst(str_replace('_', ' ', $attribute));
		
		$ATTRIBUTES_TH .= "\t\t<th>$attribute_text</th>\n";
		
		
		if ($is_foreign_key)
			$ATTRIBUTES_TD .= "\t\t\t<td><?php if (\$".$VAR_SING."->".$association_name."()) echo \"<a href=\\\"".$association_name."s.php?a=show&amp;id=\".\$".$VAR_SING."->".$attribute.".\"\\\">\".\$".$VAR_SING."->".$association_name."()->".$association_main_attribute.".\"</a>\"; ?></td>\n";
		else
			$ATTRIBUTES_TD .= "\t\t\t<td><?php echo \$".$VAR_SING."->$attribute; ?></td>\n";
		
		
		if ($is_foreign_key)
			$ATTRIBUTES_SHOW .= "\t<tr>
\t\t<td class= \"label\">$attribute_text</td>
\t\t<td><?php if (\$_".$VAR_SING."->".$association_name."()) echo \"<a href=\\\"".$association_name."s.php?a=show&amp;id=\".\$_".$VAR_SING."->".$attribute.".\"\\\">\".\$_".$VAR_SING."->".$association_name."()->".$association_main_attribute.".\"</a>\"; ?></td>
\t</tr>\n";
		else		
			$ATTRIBUTES_SHOW .= "\t<tr>
\t\t<td class= \"label\">$attribute_text</td>
\t\t<td><?php echo \$_".$VAR_SING."->$attribute; ?></td>
\t</tr>\n";


		if ($is_foreign_key)
			$ATTRIBUTES_FORM .= "\t<tr>
\t\t<td class= \"label\">$attribute_text</td>
\t\t<td<?php if (\$_".$VAR_SING."->is_error_on(\"$attribute\")) echo \" class='error'\"; ?>>
\t\t\t<select id=\"".$VAR_SING."_".$attribute."\" name=\"".$VAR_SING."[".$attribute."]\">
\t\t\t\t<?php echo options_for_select(\$_".$VAR_SING.", \"$attribute\", ".$association_class_name."::meta()->find_id_value_array(\"".$association_main_attribute."\")); ?>
\t\t\t</select>
\t\t</td>
\t</tr>\n";
		else
			$ATTRIBUTES_FORM .= "\t<tr>
\t\t<td class= \"label\">$attribute_text</td>
\t\t<td<?php if (\$_".$VAR_SING."->is_error_on(\"$attribute\")) echo \" class='error'\"; ?>>
\t\t\t<?php echo text_field(\$_".$VAR_SING.", \"".$VAR_SING."\", \"$attribute\"); ?>
\t\t</td>
\t</tr>\n";

		if ($is_first)
			$ATTRIBUTE_EXAMPLE = $attribute;
		$is_first = false;
	}
}

/*
	Other strings + replacement arrays creation
*/
$TEXT_SING = str_replace('_', ' ', $VAR_SING);
$TEXT_SING_UCFIRST = ucfirst($TEXT_SING);
$TEXT_PLUR_UCFIRST = ucfirst(str_replace('_', ' ', $VAR_PLUR));

$needle = array(
	"{{CLASS_NAME}}",
	"{{TABLE_NAME}}",
	"{{BELONGS_TO_ASSOCIATIONS}}",
	"{{VAR_SING}}",
	"{{VAR_PLUR}}",
	"{{TEXT_SING}}",
	"{{TEXT_SING_UCFIRST}}",
	"{{TEXT_PLUR_UCFIRST}}",
	"{{ATTRIBUTES_TH}}",
	"{{ATTRIBUTES_TD}}",
	"{{ATTRIBUTES_SHOW}}",
	"{{ATTRIBUTES_FORM}}",
	"{{ATTRIBUTE_EXAMPLE}}"
);

$replacement = array(
	$CLASS_NAME,
	$TABLE_NAME,
	$BELONGS_TO_ASSOCIATIONS,
	$VAR_SING,
	$VAR_PLUR,
	$TEXT_SING,
	$TEXT_SING_UCFIRST,
	$TEXT_PLUR_UCFIRST,
	$ATTRIBUTES_TH,
	$ATTRIBUTES_TD,
	$ATTRIBUTES_SHOW,
	$ATTRIBUTES_FORM,
	$ATTRIBUTE_EXAMPLE
);

/*
	Model compiling
*/
$model_file = SCRIPTS_DIR."../models/$VAR_SING.class.php";
if (file_exists($model_file))
	die("ERROR : File $model_file already exists.\n");
if (! $f = fopen($model_file, "w"))
	die("ERROR : Can't create $model_file file.\n");

$model_template = TEMPLATES_DIR."model.php";
$contents = file_get_contents($model_template);
$contents = str_replace($needle, $replacement, $contents);
fwrite($f, $contents);
fclose($f);

/*
	Controller compiling
*/
$controller_file = SCRIPTS_DIR."../$VAR_PLUR.php";
if (file_exists($controller_file))
	die("ERROR : File $controller_file already exists.\n");
if (! $f = fopen($controller_file, "w"))
	die("ERROR : Can't create $controller_file file.\n");

$model_template = TEMPLATES_DIR."controller.php";
$contents = file_get_contents($model_template);
$contents = str_replace($needle, $replacement, $contents);
fwrite($f, $contents);
fclose($f);

/*
	Views compiling
*/
$views_dir = SCRIPTS_DIR."../views/$VAR_PLUR/";
if (file_exists($views_dir))
	die("ERROR : Directory $views_dir already exists.\n");
if (! mkdir($views_dir))
	die("ERROR : Can't create $views_dir directory.\n");
	
$dh = opendir(TEMPLATES_DIR."views/");
while (($file = readdir($dh)) !== false)
{
	if (ereg("\.php$", $file))
	{
		$template = TEMPLATES_DIR."views/$file";
		$file = SCRIPTS_DIR."../views/$VAR_PLUR/".$file;
		if (file_exists($file))
			die("ERROR : File $file already exists.\n");
		if (! $f = fopen($file, "w"))
			die("ERROR : Can't create $file file.\n");
		$contents = file_get_contents($template);
		$contents = str_replace($needle, $replacement, $contents);
		fwrite($f, $contents);
		fclose($f);
	}
}
closedir($dh);

// Finalement :
echo "\n";
?>
