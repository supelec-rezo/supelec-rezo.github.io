<?php
	// belongs_to : {{ASSOCIATION_NAME}}
	private $_{{ASSOCIATION_NAME}} = false;
	public function {{ASSOCIATION_NAME}}($force_reload = false)
	{
		if ($force_reload || $this->_{{ASSOCIATION_NAME}} === false)
			$this->_{{ASSOCIATION_NAME}} = {{FOREIGN_CLASS_NAME}}::meta()->find_one("id = ".rdg_p($this->{{FOREIGN_KEY}}));
		return $this->_{{ASSOCIATION_NAME}};
	}
?>
