<?php
class {{CLASS_NAME}} extends RDG
{
	
	/****************************************************************************
		Associations
	****************************************************************************/
	{{BELONGS_TO_ASSOCIATIONS}}
	
	
	/****************************************************************************
		Validation
	****************************************************************************/
	protected function validation()
	{
// 		if (! $this->{{ATTRIBUTE_EXAMPLE}})
// 			$this->add_error_on("{{ATTRIBUTE_EXAMPLE}}", "can't be blank");
// 
// 		if ($this->meta()->count("name = ".rdg_p($this->{{ATTRIBUTE_EXAMPLE}})." AND id != ".intval($this->id)) > 0)
// 			$this->add_error_on("{{ATTRIBUTE_EXAMPLE}}", "is already taken");
	}
	
	/****************************************************************************
		Callbacks
	****************************************************************************/

	/****************************************************************************
		Design Pattern RDG
	****************************************************************************/
	public static function meta()
	{
		$class_name = get_class();
		if (! parent::is_meta($class_name))
		{
			$table_name = "{{TABLE_NAME}}";
			$meta = new RDGMeta($class_name, $table_name); // Paramètres constructeurs
			// [Inclure ici les paramètres non-constructeurs]
			$meta->set_default_order("id");
			parent::add_meta($meta);
		}
		return parent::get_meta($class_name);
	}
}
?>