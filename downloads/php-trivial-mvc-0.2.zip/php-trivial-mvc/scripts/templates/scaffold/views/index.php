<h1>{{TEXT_PLUR_UCFIRST}}</h1>

<?php
$num = sizeof($_{{VAR_PLUR}});
if ($num == 0)
{
?>
	<p>None.</p>
<?php
}
else
{
?>
	<p><?php echo $num." result".($num > 1 ? "s" : ""); ?>.</p>

	<p><table class="list">
	<tr>
{{ATTRIBUTES_TH}}
		<th></th>
	</tr>
	<?php
	$row = 0;
	foreach ($_{{VAR_PLUR}} as ${{VAR_SING}})
	{
	?>
		<tr class="row<?php echo $row; ?>">
{{ATTRIBUTES_TD}}
			<td>
				<a href="{{VAR_PLUR}}.php?a=edit&amp;id=<?php echo ${{VAR_SING}}->id; ?>"><img src="images/icons/edit.png" alt="Edit" title="Edit"/></a>
				<a href="{{VAR_PLUR}}.php?a=destroy&amp;id=<?php echo ${{VAR_SING}}->id; ?>" onclick="<?php echo confirm_onclick(); ?>"><img src="images/icons/delete.png" alt="Delete" title="Delete"/></a>
				<a href="{{VAR_PLUR}}.php?a=show&amp;id=<?php echo ${{VAR_SING}}->id; ?>"><img src="images/icons/forward.png" alt="Show" title="Show"/></a>
			</td>
		</tr>
	<?php
		$row = 1 - $row;
	}
	?>
	</table></p>

<?php
}
?>

<p><a href="{{VAR_PLUR}}.php?a=add"><img src="images/icons/add.png" alt="New" title="New" /></a></p>