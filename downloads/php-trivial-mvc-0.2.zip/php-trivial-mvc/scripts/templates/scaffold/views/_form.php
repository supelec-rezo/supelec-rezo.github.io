<?php error_messages_for($_{{VAR_SING}}); ?>

<p>
<table>
{{ATTRIBUTES_FORM}}
</table>
</p>
