<h1>Edit {{TEXT_SING}}</h1>

<form method="post" action="{{VAR_PLUR}}.php?a=update&amp;id=<?php echo $_{{VAR_SING}}->id; ?>&amp;r=<?php echo is_param('r') ? param('r') : 'index'; ?>">
	<?php require "_form.php"; ?>
	<p>
		<input type="submit" name="submit" id="submit" value="OK" />
		<input type="button" name="cancel" id="cancel" value="Cancel" onclick="javascript:location.href='{{VAR_PLUR}}.php<?php echo is_param('r') && param('r') == 'show' ? "?a=show&id=".$_{{VAR_SING}}->id : ""; ?>';" />
	</p>
</form>
