<?php
define('CONTROLLER', substr(basename(__FILE__), 0, strlen(basename(__FILE__)) - 4));
define('ACTION', isset($_GET['a']) ? $_GET['a'] : 'index');

try
{
	require 'include/include.php';

	switch (ACTION)
	{
		/*************************************************************************/
		case 'index':
			$_{{VAR_PLUR}} = {{CLASS_NAME}}::meta()->find_all();
			$view->render();
		break;

		/*************************************************************************/
		case 'show':
			$id = param('id');
			$_{{VAR_SING}} = {{CLASS_NAME}}::meta()->find($id);
			$view->render();
		break;
		
		/*************************************************************************/
		case 'add':
			$_{{VAR_SING}} = new {{CLASS_NAME}};
			$view->render();
		break;

		/*************************************************************************/
		case 'edit':
			$id = param('id');
			$_{{VAR_SING}} = {{CLASS_NAME}}::meta()->find($id);
			$view->render();
		break;

		/*************************************************************************/
		case 'create':
			$_{{VAR_SING}} = new {{CLASS_NAME}}(param('{{VAR_SING}}'));
			if ($_{{VAR_SING}}->save())
			{
				flash('notice', "{{TEXT_SING_UCFIRST}} successfully created.");
				$view->redirect("{{VAR_PLUR}}.php");
			}
			else
			{
				$view->set_template("add");
				$view->render();
			}
		break;

		/*************************************************************************/
		case 'update':
			$id = param('id');
			$_{{VAR_SING}} = {{CLASS_NAME}}::meta()->find($id);
			$_{{VAR_SING}}->update_attributes(param('{{VAR_SING}}'));
			if ($_{{VAR_SING}}->save())
			{
				flash('notice', "{{TEXT_SING_UCFIRST}} successfully updated.");
 				if (is_param('r') && param('r') == "show")
 					$view->redirect("{{VAR_PLUR}}.php?a=show&id=$id");
 				else
					$view->redirect("{{VAR_PLUR}}.php");
			}
			else
			{
				$view->set_template("edit");
				$view->render();
			}
		break;

		/*************************************************************************/
		case 'destroy':
			if ($_SERVER['REQUEST_METHOD'] != 'POST')
				throw new Exception("POST method required.");
			$id = param('id');
			${{VAR_SING}} = {{CLASS_NAME}}::meta()->find($id);
			${{VAR_SING}}->destroy();
			flash('notice', "{{TEXT_SING_UCFIRST}} successfully deleted.");

			$view->redirect("{{VAR_PLUR}}.php");
		break;

		/*************************************************************************/
		default :
			throw new Exception("Unknown action '".ACTION."'.");
		break;
	}
}
catch (Exception $e)
{
	$view->render_exception($e);
}
?>
