<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**
	Exceptions utilisées par PhpRDG.
*/


/**
	Erreur suite à une requête SQL
*/
class RDGExceptionMySQL extends Exception
{
	/**
		@param	string	Description de l'erreur par mysql_error().
		@param	string	Requête ayant généré l'erreur.
	*/
	public function __construct($description, $query = null)
	{
		$message  = "Mysql error : $description";
		if ($query)
			$message .= "<br />\nQuery : $query";
		parent::__construct($message);
	}
}


/**
	Attribut inconnu.
*/
class RDGExceptionUnknownAttribute extends Exception
{
	/**
		@param	string	Nom de la classe
		@param	string	Attribut recherché
	*/
	public function __construct($class_name, $attribute)
	{
		$message = "Unknown attribute '".$attribute."' in class '".$class_name."'";
		parent::__construct($message);
	}
}

/**
	Enregistrement	non	trouvé.
*/
class RDGExceptionNotFound extends Exception
{
	/**
		@param	string	Nom de la classe
		@param	string	Valeur recherchée de la clé primaire
	*/
	public function __construct($class_name, $id)
	{
		$message = "Record '$id' not found in class '".$class_name."'";
		parent::__construct($message);
	}
}
?>
