<?php
/*

	Copyright 2008, Sébastien Hocquet.
	All rights reserved - Tous droits réservés.

	This software is provided under the BSD license. See COPYING file for terms
	and conditions.

	Ce logiciel est publié suivant les termes de la licence BSD. Lisez le fichier
	COPYING pour en connaître les termes et les conditions.

*/

/**
  Fichier permettant l'inclusion de PhpRDG dans un projet.
*/

/* Fichiers à éditer éventuellement */
require "config.php";
require "environment.php";

/* Fichiers requis */
require "exceptions.php";
require "utils.php";
require "rdg.class.php";
require "rdg_meta.class.php";

/* Facultatif (sauvegarde / restauration d'une base de données) */
// require "extensions.php";
?>
